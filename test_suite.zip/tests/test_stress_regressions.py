from dataclasses import replace
import math
import pytest
from pharmaform_core import Target,parse_dose,build_proposal,validate_rows,dose_calculation
from pharmaform_identity import international_name,NAMES
from pharmaform_leaflets import parse_leaflet,safe_url
from pharmaform_resolver import verified_hcl
from pharmaform_research import fda_labels

@pytest.mark.parametrize('pt,en',list(NAMES.items()))
def test_chemical_search_translation(pt,en):
    assert international_name('Cloridrato de '+pt)==en+' hydrochloride'

@pytest.mark.parametrize('field',['mw_base','mw_material','dry_mass_g'])
@pytest.mark.parametrize('value',[-1,float('nan'),float('inf')])
def test_nonfinite_inputs_rejected(field,value):
    t=Target('X','Y','10 mg');setattr(t,field,value)
    with pytest.raises(ValueError):t.validate()

@pytest.mark.parametrize('dose',[.001,.01,.1,1,10,50,100,500,1000])
@pytest.mark.parametrize('potency',[50,90,98,100])
@pytest.mark.parametrize('form',['Cápsula dura','Comprimido simples','Comprimido revestido'])
def test_general_mass_stress(dose,potency,form):
    t=Target('Produto inédito','API de teste',f'{dose} mg',form=form,release='Convencional',
        mass_mg=max(200,dose*4),dose_basis='Material informado (sal/IFA)',potency_pct=potency)
    s={'id':'FIXTURE','scope':'Candidata','target_q1':True,'q1':['Lactose','Crospovidona','Estearato de magnésio'],
       'architecture':'Conventional tablets','finding':'Fixture de teste'}
    p=build_proposal(t,[s]);assert p.rows
    assert not validate_rows(p.rows,p.mass_total_mg,dose/(potency/100))
    assert p.calculations['weighed_mg']==pytest.approx(dose/(potency/100),abs=1e-6)

@pytest.mark.parametrize('shell',['gelatina e dióxido de titânio','gelatina, óxido de ferro amarelo e dióxido de titânio'])
def test_strength_specific_brazilian_leaflet(shell):
    text=f'ATENTAH Cápsula dura COMPOSIÇÃO Cada cápsula de 40 mg contém: Cloridrato de atomoxetina (equivalente a 40 mg de atomoxetina) 45,711 mg excipientes qsp 1 cápsula Excipientes: lactose. Cada cápsula de 60 mg contém: Cloridrato de atomoxetina (equivalente a 60 mg de atomoxetina) 68,567 mg excipientes qsp 1 cápsula Excipientes: amido, estearato de magnésio, {shell}. Cada cápsula de 80 mg contém:'
    t=Target('Atentah','','60 mg',form='Cápsula dura')
    s=parse_leaflet(text,t,'https://produtos.apsen.com.br/atentah')
    assert s and s['target_q1']
    assert 'Lactose' not in s['q1']
    assert 'gelatina' not in str(s['q1']).lower()
    assert dose_calculation(t)['weighed_mg']==68.567
    assert build_proposal(t,[s]).rows
    assert parse_leaflet(text,replace(t,dose='50 mg'),'https://produtos.apsen.com.br/atentah') is None

@pytest.mark.parametrize('url',['http://127.0.0.1','https://produtos.apsen.com.br.evil.org/a','https://localhost/a','file:///etc/passwd','https://user:pass@produtos.apsen.com.br/a'])
def test_untrusted_leaflet_urls_rejected(url):assert not safe_url(url)

def test_formula_verification_not_just_mass_difference():
    base={'MolecularFormula':'C17H21NO','MolecularWeight':255.35}
    assert verified_hcl({'MolecularFormula':'C17H22ClNO','MolecularWeight':291.81},base)
    assert not verified_hcl({'MolecularFormula':'C17H24ClNO2','MolecularWeight':291.81},base)
    assert not verified_hcl({'MolecularFormula':'C17H23Cl2NO','MolecularWeight':328.27},base)

def test_label_strength_mismatch_does_not_supply_q1(monkeypatch):
    import pharmaform_research as r
    item={'id':'test','openfda':{'brand_name':['Product'],'generic_name':['ATOMOXETINE HYDROCHLORIDE'],'substance_name':['ATOMOXETINE HYDROCHLORIDE']},
       'description':['Capsules contain atomoxetine hydrochloride. Inactive ingredients: pregelatinized starch, magnesium stearate.'],
       'dosage_forms_and_strengths':['Capsules 40 mg'],'active_ingredient':['atomoxetine 40 mg']}
    monkeypatch.setattr(r,'get_url',lambda *a,**kw:({'results':[item]},None))
    rows,*_=fda_labels(Target('Product','Atomoxetine hydrochloride','60 mg',form='Cápsula dura'))
    assert rows and not any(s['target_q1'] for s in rows)

def test_pubchem_brand_title_does_not_turn_salt_into_free_base(monkeypatch):
    import pharmaform_resolver as r
    material={'CID':62857,'Title':'Reconcile','MolecularFormula':'C17H19ClF3NO','MolecularWeight':345.8}
    base={'CID':3386,'Title':'Fluoxetine','MolecularFormula':'C17H18F3NO','MolecularWeight':309.33}
    def props(name):
        x=material if 'hydrochloride' in international_name(name) else base
        return x,{'id':'PUBCHEM-'+str(x['CID'])}
    monkeypatch.setattr(r,'properties',props)
    t=Target('','Cloridrato de fluoxetina','20 mg')
    r.resolve_initial(t)
    assert t.mw_material==345.8 and t.mw_base==309.33
    assert dose_calculation(t)['weighed_mg']>22

def test_unknown_dose_basis_requires_confirmation():
    t=Target('Product','Metformin hydrochloride','500 mg',dose_basis='Identificar pela bula',mw_base=129.16,mw_material=165.62)
    with pytest.raises(ValueError,match='base da concentração'):dose_calculation(t)

def test_capsule_starch_is_used_as_fill_instead_of_inventing_diluent():
    t=Target('X','Y','60 mg',form='Cápsula dura',release='Convencional',dose_basis='Material informado (sal/IFA)')
    s={'id':'S','scope':'Bula','target_q1':True,'q1':['Amido (grau a conferir)','Estearato de magnésio'],'architecture':'capsule','finding':''}
    p=build_proposal(t,[s])
    assert p.rows
    assert not any('Celulose' in r['Componente'] for r in p.rows)
    assert any('Amido' in r['Componente'] and 'q.s.p' in r['Função'] for r in p.rows)

@pytest.mark.parametrize('material',['Esomeprazole magnesium','Atorvastatin calcium','Drug monohydrate','Quetiapine fumarate','Drug sulfate','Drug citrate'])
def test_complex_salts_never_default_to_free_base(monkeypatch,material):
    import pharmaform_resolver as r
    monkeypatch.setattr(r,'properties',lambda n:({'CID':9,'Title':'Brand-like title','MolecularFormula':'C10H20O','MolecularWeight':200},{'id':'P9'}))
    t=Target('',material,'10 mg')
    r.resolve_initial(t)
    assert t.mw_material == t.mw_base == 0
    with pytest.raises(ValueError):dose_calculation(t)
