import copy
import json
from io import BytesIO
from dataclasses import replace

import pytest
from pypdf import PdfReader

from pharmaform_core import Target, build_proposal, core_masses, dose_calculation, parse_dose, validate_rows
from pharmaform_research import classify, extract_q1, numeric_examples, research
from pharmaform_report import payload, pdf_report


@pytest.fixture
def gua():
    return Target("Intuniv", "Cloridrato de guanfacina", "4 mg de guanfacina base")


@pytest.mark.parametrize("value, expected, per_ml", [("4 mg de base", 4, False), ("0,5 mg", .5, False), ("250 µg", .25, False), ("0.4 g", 400, False), ("6 mg/mL", 6, True)])
def test_dose_units(value, expected, per_ml):
    assert parse_dose(value) == (expected, per_ml)


@pytest.mark.parametrize("value", ["-4 mg", "0 mg", "4 mg + 5 mg", "1.000 UI", "250 mg/5mL", "10 mg/g"])
def test_reject_ambiguous_doses(value):
    with pytest.raises(ValueError):
        parse_dose(value)


def test_base_salt_conversion_and_potency(gua):
    p = dose_calculation(gua)
    assert p["weighed_mg"] == pytest.approx(4 * 282.55 / 246.09, abs=1e-6)
    assert dose_calculation(replace(gua, potency_pct=98))["weighed_mg"] == pytest.approx(p["weighed_mg"] / .98, abs=2e-6)
    assert dose_calculation(replace(gua, dose_basis="Material informado (sal/IFA)"))["weighed_mg"] == 4


def test_coating_mass_basis(gua):
    core, coat, final = core_masses(gua)
    assert final == 200
    assert core + coat == pytest.approx(200, abs=1e-6)
    assert core == pytest.approx(200 / 1.03, abs=1e-6)
    assert core_masses(replace(gua, mass_basis="Núcleo / conteúdo")) == (200, 6, 206)


def test_closed_model_and_distinct_routes(gua):
    cd = build_proposal(gua)
    wet = build_proposal(replace(gua, route="Granulação úmida"))
    assert not validate_rows(cd.rows, 200, cd.calculations["weighed_mg"])
    assert not validate_rows(wet.rows, 200, wet.calculations["weighed_mg"])
    assert "composição 1" in cd.rationale[0]
    assert any("HPMCP" in r["Componente"] for r in wet.rows)
    assert all("A definir" not in str(r) for r in cd.rows)


def test_no_silent_identity_or_salt_swap():
    with pytest.raises(ValueError):
        build_proposal(Target("Intuniv", "Metformin", "4 mg"))
    with pytest.raises(ValueError):
        build_proposal(Target("Intuniv", "Sulfato de guanfacina", "4 mg"))


def test_does_not_transplant_lp_to_ir(gua):
    result = build_proposal(replace(gua, release="Convencional"))
    assert not result.rows


def test_impossible_load_is_explicit(gua):
    result = build_proposal(replace(gua, dose="150 mg"))
    assert not result.rows
    assert any("excede" in x for x in result.gaps)


def test_manual_invalid_edits_are_detected(gua):
    p = build_proposal(gua)
    rows = copy.deepcopy(p.rows)
    rows[0]["mg/unidade"] = 4
    assert any("IFA difere" in x for x in validate_rows(rows, 200, p.calculations["weighed_mg"]))
    rows[0]["mg/unidade"] = float("nan")
    assert any("finita" in x for x in validate_rows(rows, 200))
    rows = copy.deepcopy(p.rows)
    rows[1]["Fontes"] = ""
    assert any("fonte" in x for x in validate_rows(rows, 200))


def test_suspension_not_capsules_or_water_equal_volume():
    t = Target("Tamiflu", "Fosfato de oseltamivir", "6 mg/mL", form="Pó para suspensão oral")
    p = build_proposal(t)
    assert p.unit == "frasco"
    assert p.calculations["base_or_material_total_mg"] == 360
    assert p.mass_total_mg > 10000
    assert not validate_rows(p.rows, p.mass_total_mg, p.calculations["weighed_mg"])
    assert any("água" in s for s in p.steps)


def q1_source():
    return {"id": "UNSEEN-LABEL", "scope": "Candidata documental", "target_q1": True,
            "q1": ["Celulose microcristalina", "Crospovidona", "Povidona", "Estearato de magnésio", "Sílica"],
            "architecture": "Conventional tablets", "finding": "Q1 de uma referência não cadastrada"}


@pytest.mark.parametrize("drug,api", [("Referência nunca cadastrada A", "API A"), ("Outra referência B", "API B")])
def test_unseen_product_gets_general_q2_without_a_drug_profile(drug, api):
    t = Target(drug, api, "25 mg", release="Convencional", dose_basis="Material informado (sal/IFA)")
    p = build_proposal(t, [q1_source()])
    assert len(p.rows) >= 5
    assert p.calculations["method"].startswith("Inferência funcional")
    assert not validate_rows(p.rows, 200, 25)
    assert p.rows[0]["Componente"] == api
    assert all("guanfacin" not in str(r).lower() for r in p.rows)
    assert all("Hipótese" in r["Origem da quantidade"] or "Calculada" in r["Origem da quantidade"] for r in p.rows)


def test_q1_changes_the_proposal():
    t = Target("Unknown", "Unknown API", "25 mg", release="Convencional", dose_basis="Material informado (sal/IFA)")
    a = q1_source()
    b = q1_source()
    b["q1"] = ["Lactose", "Croscarmelose", "Fumarato estearílico de sódio"]
    pa, pb = build_proposal(t, [a]), build_proposal(t, [b])
    assert pa.rows != pb.rows
    assert any(r["Componente"] == "Lactose" for r in pb.rows)
    assert not any(r["Componente"] == "Sílica" for r in pb.rows)


def test_no_formula_from_other_presentation_or_metadata():
    t = Target("Unknown", "Unknown API", "25 mg", release="Convencional", dose_basis="Material informado (sal/IFA)")
    source = q1_source()
    source["scope"] = "Outra forma: não usar como Q2"
    assert not build_proposal(t, [source]).rows
    source["scope"], source["target_q1"] = "Título/metadados", False
    assert not build_proposal(t, [source]).rows


def test_matrix_requires_architecture_evidence():
    t = Target("New LP", "API", "10 mg", release="Prolongada", dose_basis="Material informado (sal/IFA)")
    s = q1_source()
    s["q1"].append("Hipromelose")
    assert not build_proposal(t, [s]).rows
    s["architecture"] = "Hydrophilic matrix tablet"
    assert build_proposal(t, [s]).rows


def test_delayed_release_does_not_become_ir():
    t = Target("Enteric", "API", "20 mg", release="Retardada", dose_basis="Material informado (sal/IFA)")
    assert not build_proposal(t, [q1_source()]).rows


def test_identity_filter_and_lp_classification(gua):
    assert classify("Cache comprimido adaptativo", gua).startswith("Descartada")
    assert "matriz/LP" in classify("Guanfacine hydrochloride extended-release matrix tablet", gua)
    assert classify("Guanfacine immediate-release tablet", gua).startswith("Outra liberação")


def test_q1_not_extracted_from_interactions():
    assert not extract_q1("Patients received povidone in an unrelated clinical trial")
    assert "Hipromelose" in extract_q1("The tablets also contain hypromellose, lactose, crospovidone.")
    assert "Povidona" not in extract_q1("Inactive ingredients: crospovidone")


def test_association_label_not_used_for_single_api(monkeypatch):
    import pharmaform_research as module
    def response(*args, **kwargs):
        return {"results": [
            {"id":"combo", "openfda":{"brand_name":["Brand"],"generic_name":["ACETAMINOPHEN, DEXTROMETHORPHAN HYDROBROMIDE"]}, "inactive_ingredient":["lactose, magnesium stearate"], "spl_product_data_elements":["Brand tablet"]},
            {"id":"single", "openfda":{"brand_name":["Brand"],"generic_name":["ACETAMINOPHEN"], "substance_name":["ACETAMINOPHEN"]}, "inactive_ingredient":["lactose, magnesium stearate"], "spl_product_data_elements":["Brand tablet"]},
        ]}, None
    monkeypatch.setattr(module, "get_url", response)
    records, _, _, _ = module.fda_labels(Target("Brand", "Acetaminophen", "500 mg", release="Convencional"))
    assert len(records) == 1
    assert "combo" not in records[0]["url"]


def test_numeric_patent_requires_closed_percentage_column():
    t = Target("Exampledrug", "Exampledrug", "10 mg", release="Convencional", dose_basis="Material informado (sal/IFA)")
    html = '<table><tr><th>Ingredient</th><th>% w/w</th></tr><tr><td>Exampledrug</td><td>10</td></tr><tr><td>Lactose</td><td>85</td></tr><tr><td>Crospovidone</td><td>4</td></tr><tr><td>Magnesium stearate</td><td>1</td></tr></table>'
    assert numeric_examples(html, "P", t, "Candidata")
    assert not numeric_examples(html.replace("85", "80-90"), "P", t, "Candidata")
    assert not numeric_examples(html.replace("85", "70"), "P", t, "Candidata")


def test_pdf_contains_proposal_sources_and_fresh_values(gua):
    p = build_proposal(gua)
    bundle = research(gua, online=False)
    body = payload(p, bundle)
    pdf = pdf_report(body)
    text = "\n".join(page.extract_text() for page in PdfReader(BytesIO(pdf)).pages)
    assert "PAT-GUA" in text
    assert "Proposta experimental" in text
    assert "4.592629" in text or "4.592630" in text
    assert "A definir" not in text
    altered = copy.deepcopy(p.rows)
    altered[-1]["mg/unidade"] += 1
    assert payload(p, bundle, altered)["content_sha256"] != body["content_sha256"]
