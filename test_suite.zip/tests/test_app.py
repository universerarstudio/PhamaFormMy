from pathlib import Path
from streamlit.testing.v1 import AppTest

def app(monkeypatch):
    monkeypatch.setenv('PHARMAFORM_OFFLINE','1')
    return AppTest.from_file(str(Path(__file__).parents[1]/'app.py'),default_timeout=30).run()

def enter(a, product, api, dose):
    a.text_input(key='product').set_value(product)
    a.text_input(key='api').set_value(api)
    a.text_input(key='dose').set_value(dose)
    return next(b for b in a.button if b.label=='Pesquisar e gerar proposta').click().run()

def test_input_to_proposal_and_pdf_without_network(monkeypatch):
    a=app(monkeypatch)
    assert not any('Exemplo' in b.label for b in a.button)
    assert a.text_input(key='product').value == ''
    a=enter(a,'Intuniv','Cloridrato de guanfacina','4 mg de guanfacina base')
    assert not a.exception
    p,bundle=a.session_state['result']
    assert p.rows and p.calculations['weighed_mg']>4.5
    assert not bundle['online']

def test_new_search_replaces_old_result(monkeypatch):
    a=enter(app(monkeypatch),'Intuniv','Cloridrato de guanfacina','4 mg')
    a=enter(a,'Produto desconhecido','Composto desconhecido','60 mg')
    assert not a.exception
    p,_=a.session_state['result']
    assert p.target['product']=='Produto desconhecido'
    assert not p.rows

def test_invalid_search_removes_previous_report(monkeypatch):
    a=enter(app(monkeypatch),'Intuniv','Cloridrato de guanfacina','4 mg')
    a=enter(a,'','','60 mg')
    assert 'result' not in a.session_state
    assert len(a.error)>0
