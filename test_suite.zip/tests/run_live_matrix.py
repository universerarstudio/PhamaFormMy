from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,sys,traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pharmaform_core import Target,build_proposal,validate_rows
from pharmaform_research import research
from pharmaform_report import payload,pdf_report
CASES=[('Atentah','','60 mg','Cápsula dura','Identificar pela referência'),('Atentah','Cloridrato de atomoxetina','60 mg','Cápsula dura','Identificar pela referência'),('Atentah','Atomoxetine hydrochloride','60 mg','Cápsula dura','Identificar pela referência'),('Intuniv','Cloridrato de guanfacina','4 mg','Comprimido revestido','Identificar pela referência'),('Tylenol','Paracetamol','500 mg','Comprimido simples','Convencional'),('Advil','Ibuprofeno','200 mg','Comprimido revestido','Convencional'),('Glucophage','Cloridrato de metformina','500 mg','Comprimido revestido','Convencional'),('Zoloft','Cloridrato de sertralina','50 mg','Comprimido revestido','Convencional'),('Prozac','Cloridrato de fluoxetina','20 mg','Cápsula dura','Convencional'),('Ritalin','Cloridrato de metilfenidato','10 mg','Comprimido simples','Convencional'),('Concerta','Cloridrato de metilfenidato','18 mg','Comprimido revestido','Prolongada'),('Prilosec','Omeprazol','20 mg','Cápsula dura','Retardada'),('Nexium','Esomeprazole magnesium','20 mg','Cápsula dura','Retardada'),('Seroquel','Fumarato de quetiapina','25 mg','Comprimido revestido','Convencional'),('Lipitor','Atorvastatin calcium','10 mg','Comprimido revestido','Convencional'),('Claritin','Loratadina','10 mg','Comprimido simples','Convencional'),('Zyrtec','Cloridrato de cetirizina','10 mg','Comprimido simples','Convencional'),('Wellbutrin XL','Cloridrato de bupropiona','150 mg','Comprimido revestido','Prolongada'),('Tamiflu','Fosfato de oseltamivir','6 mg/mL','Pó para suspensão oral','Convencional'),('Produto inexistente XYZ','','60 mg','Cápsula dura','Convencional'),('Intuniv','Cloridrato de metformina','4 mg','Comprimido revestido','Prolongada'),('Atentah','Cloridrato de sertralina','60 mg','Cápsula dura','Convencional')]
out=Path(sys.argv[1] if len(sys.argv)>1 else '../live_matrix');out.mkdir(exist_ok=True,parents=True)
def run(pair):
 i,c=pair;result={'case':i,'product':c[0],'api_input':c[1],'dose':c[2],'form':c[3]}
 try:
  t=Target(*c[:3],form=c[3],release=c[4],mass_mg=1000 if '500' in c[2] else 350,mass_basis='Núcleo / conteúdo')
  b=research(t);p=build_proposal(t,b['sources'],b['examples'])
  errors=validate_rows(p.rows,p.mass_total_mg,p.calculations.get('weighed_mg')) if p.rows else []
  result.update(outcome='invalid' if errors else 'computed' if p.rows else 'blocked',errors=errors,status=p.status,weighed_mg=p.calculations.get('weighed_mg'),sources=len(b['sources']),issues=b['issues'],gaps=p.gaps,warnings=p.warnings)
  body=payload(p,b);(out/f'case_{i:02}.json').write_text(json.dumps(body,ensure_ascii=False,indent=2))
  if p.rows:(out/f'case_{i:02}.pdf').write_bytes(pdf_report(body))
 except ValueError as e:result.update(outcome='input_rejected',reason=str(e))
 except Exception as e:result.update(outcome='exception',reason=repr(e),traceback=traceback.format_exc())
 print(json.dumps(result,ensure_ascii=False),flush=True)
 (out/f'result_{i:02}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));return result
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,enumerate(CASES,1)))
(out/'summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
