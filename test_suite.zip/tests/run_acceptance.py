"""Live acceptance cases. Not part of offline CI; emits actual source coverage."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pharmaform_core import Target, build_proposal, validate_rows
from pharmaform_report import payload, pdf_report
from pharmaform_research import research


CASES = [
    (Target("Intuniv", "Cloridrato de guanfacina", "4 mg de guanfacina base"), True),
    (Target("Tylenol", "Paracetamol", "500 mg", mass_mg=700, release="Convencional"), True),
    (Target("Advil", "Ibuprofen", "200 mg", mass_mg=350, release="Convencional"), True),
    (Target("Glucophage", "Metformin hydrochloride", "500 mg", mass_mg=700, release="Convencional", dose_basis="Material informado (sal/IFA)"), True),
    (Target("Tamiflu", "Fosfato de oseltamivir", "6 mg/mL", form="Pó para suspensão oral"), True),
    (Target("Prilosec", "Omeprazole", "20 mg", form="Cápsula dura", release="Retardada", mass_basis="Núcleo / conteúdo"), False),
]


def run_case(pair, output):
    t, expect_closed = pair
    bundle = research(t, online=True)
    p = build_proposal(t, bundle["sources"], bundle["examples"])
    errors = validate_rows(p.rows, p.mass_total_mg, p.calculations.get("weighed_mg")) if p.rows else []
    passed = bool(p.rows) == expect_closed and not errors
    body = payload(p, bundle)
    key = t.product.lower()
    (output / (key + ".json")).write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
    if key == "intuniv":
        (output / "PharmaForm_Intuniv_04mg_200mg_exemplo.pdf").write_bytes(pdf_report(body))
    summary = {"reference": t.product, "dose": t.dose, "form": t.form, "release": t.detected_release or t.release,
               "status": p.status, "method": p.calculations.get("method"), "api_mg": p.calculations.get("weighed_mg"),
               "sum_mg": round(sum(r["mg/unidade"] for r in p.rows), 6), "expected_mass_mg": p.mass_total_mg,
               "sources": len(bundle["sources"]), "rejected": len(bundle["rejected"]),
               "network_issues": len(bundle["issues"]), "validation_errors": errors,
               "expect_closed": expect_closed, "passed": passed, "gaps": p.gaps}
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    return summary


if __name__ == "__main__":
    output = Path(sys.argv[1] if len(sys.argv) > 1 else "../acceptance_output").resolve()
    output.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda x: run_case(x, output), CASES))
    (output / "acceptance_summary.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    sys.exit(0 if all(x["passed"] for x in results) else 1)
