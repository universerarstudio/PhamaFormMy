import sys,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pharmaform_work'))
from pharmaform_core import Target,build_proposal
from pharmaform_resolver import resolve_initial,resolve_from_labels
from pharmaform_leaflets import official_leaflet
root=Path(__file__).resolve().parents[1]
def run(i):
 body=json.loads((root/'live_matrix'/f'case_{i:02}.json').read_text());old=body['proposal']['target']
 old.pop('identified_release',None)
 for k in ['mw_base','mw_material','label_factor']:old[k]=0
 for k in ['identity_terms','mw_source_ids']:old[k]=[]
 old['label_factor_source']='';old['identity_conflict']=''
 t=Target(**old)
 if i==7:t.dose_basis='Material informado (sal/IFA)'
 sources=body['research']['sources'];notes=[]
 if i in (1,2,3):
  t.api='' if i==1 else 'Cloridrato de atomoxetina'
  sources,notes,*_=official_leaflet(t)
 else:
  extra,notes=resolve_initial(t);sources+=extra
  if not t.mw_base:
   ex,issues=resolve_from_labels(t,sources);sources+=ex;notes+=issues
 p=build_proposal(t,sources)
 r={'case':i,'product':t.product,'outcome':'computed' if p.rows else 'blocked','weighed_mg':p.calculations.get('weighed_mg'),'issues':notes,'gaps':p.gaps}
 print(json.dumps(r,ensure_ascii=False),flush=True);return r
with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,[1,7,9,13,15,17,22]))
(root/'audit_1000/recheck_final.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
