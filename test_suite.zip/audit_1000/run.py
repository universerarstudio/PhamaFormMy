"""1000 distinct brand/generic labels, not 1000 claimed UI searches.

Snapshot replay through production label parsing/compiler/report. The requested
mass and material-basis dose are test parameters, not commercial Q2.
"""
import json,re,sys,traceback,csv,time,os
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,os.environ.get('PHARMAFORM_SOURCE',str(Path(__file__).resolve().parents[1]/'pharmaform_work')))
from pharmaform_core import Target,build_proposal,validate_rows
from pharmaform_research import fda_labels,REFERENCES
from pharmaform_resolver import resolve_from_labels
from pharmaform_report import payload,pdf_report
from dataclasses import asdict
root=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).parent
root.mkdir(exist_ok=True,parents=True)
source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'products.json'
items=json.loads(source.read_text())
rows=[];started=time.time()
for i,item in enumerate(items):
 f=item.get('openfda',{});brand=' | '.join(f.get('brand_name',[]));generic=' | '.join(f.get('generic_name',[]))
 result={'index':i+1,'brand':brand,'generic':generic,'label_id':item.get('id'),'manufacturer':' | '.join(f.get('manufacturer_name',[])),
  'source_url':'https://api.fda.gov/drug/label.json?search=id:'+str(item.get('id')),'outcome':None,'reason':'','pdf_bytes':0}
 try:
  dosage=' '.join(item.get('dosage_forms_and_strengths',[])+item.get('active_ingredient',[]))
  formtext=dosage+' '+' '.join(item.get('spl_product_data_elements',[]))
  forms=[n for n,p in [('Cápsula dura',r'capsul'),('Comprimido simples',r'tablet|caplet'),('Solução oral',r'oral solution'),('Pó para suspensão oral',r'suspension')] if re.search(p,formtext,re.I)]
  dose_match=re.search(r'(?<![\d.])(\d+(?:\.\d+)?)\s*(mcg|mg|g)\b',dosage,re.I)
  substances=f.get('substance_name',[])
  if len(substances)>1 or re.search(r'\band\b|,|;',generic,re.I):result.update(outcome='unsupported',reason='Associação: motor de IFA único')
  elif len(forms)!=1 or forms[0] not in ['Cápsula dura','Comprimido simples']:result.update(outcome='unsupported',reason='Forma não unitária ou múltiplas formas: revisão específica')
  elif not dose_match:result.update(outcome='blocked_missing_evidence',reason='Dose estruturada não recuperada')
  else:
   dose=float(dose_match.group(1))*{'mcg':.001,'mg':1,'g':1000}[dose_match.group(2).lower()]
   if dose<=0:raise ValueError('Invalid documentary dose')
   release='Retardada' if re.search(r'delayed.release|enteric',formtext,re.I) else 'Prolongada' if re.search(r'extended.release|sustained.release',formtext,re.I) else 'Convencional'
   t=Target(brand,substances[0] if substances else generic,f'{dose:g} mg',form=forms[0],release=release,
      mass_mg=max(200,dose*3),mass_basis='Núcleo / conteúdo',dose_basis='Material informado (sal/IFA)')
   with patch('pharmaform_research.get_url',return_value=({'results':[item]},None)):
    labels,*_=fda_labels(t)
   labels=list({x['id']:x for x in labels}.values())
   # Negative controls: wrong dose and wrong API must never reuse this label.
   from dataclasses import replace
   with patch('pharmaform_research.get_url',return_value=({'results':[item]},None)):
    mismatch,*_=fda_labels(replace(t,dose='987654321 mg'))
   if any(x.get('target_q1') for x in mismatch): raise AssertionError('Wrong strength accepted')
   wrong=replace(t,product='Unrelated product',api='Unrelated molecule XYZ',identity_terms=[])
   import copy
   other=copy.deepcopy(labels)
   with patch('pharmaform_resolver.properties',return_value=(None,None)):
    resolve_from_labels(wrong,other)
   if any(x.get('target_q1') for x in other): raise AssertionError('Wrong identity accepted')
   result['negative_controls']=2
   p=build_proposal(t,labels)
   result.update(dose_test_mg=dose,mass_test_mg=t.mass_mg,form=t.form,release=release,q1_sources=sum(bool(x.get('target_q1')) for x in labels))
   if p.rows:
    errors=validate_rows(p.rows,p.mass_total_mg,p.calculations['weighed_mg'])
    if errors:result.update(outcome='invalid',reason='; '.join(errors))
    else:
     b={'sources':labels+list(REFERENCES.values()),'issues':[],'queries':[],'rejected':[],'searched_at':'snapshot','online':False}
     data=payload(p,b);pdf=pdf_report(data)
     result.update(outcome='computed',reason='Hipótese de teste; não confirma formulação comercial',pdf_bytes=len(pdf),total_mg=p.mass_total_mg)
     if not pdf.startswith(b'%PDF'):raise AssertionError('Invalid PDF')
   else:result.update(outcome='blocked_missing_evidence',reason='; '.join(p.gaps))
 except Exception as e:result.update(outcome='exception',reason=repr(e),traceback=traceback.format_exc())
 rows.append(result)
 if (i+1)%100==0:print('AUDITED',i+1,flush=True)
(root/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
keys=sorted(set(k for x in rows for k in x))
with (root/'results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
from collections import Counter
summary={'products':len(rows),'unique_brand_generic':len(set((r['brand'],r['generic']) for r in rows)),'unique_product_manufacturer':len(set((r['brand'],r['generic'],r['manufacturer']) for r in rows)),
 'outcomes':dict(Counter(x['outcome'] for x in rows)),'duration_s':round(time.time()-started,1),
 'method':'Replay de 1000 rotulagens reais openFDA; não são 1000 buscas completas nem 1000 formulações validadas. Dose no material e peso são parâmetros de teste.'}
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False),flush=True)
