import requests,json,time,re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
out=Path(__file__).parent/'rx';out.mkdir(exist_ok=True)
base='https://api.fda.gov/drug/label.json'
query='openfda.route:"ORAL" AND openfda.product_type:"HUMAN PRESCRIPTION DRUG" AND _exists_:openfda.brand_name'
def fetch(skip):
 p=out/f'page_{skip:05}.json'
 if p.exists(): return json.loads(p.read_text())
 for attempt in range(3):
  try:
   r=requests.get(base,params={'search':query,'limit':100,'skip':skip},timeout=60); r.raise_for_status(); data=r.json(); p.write_text(json.dumps(data)); return data
  except Exception as e:
   if attempt==2: print('FETCH_FAILURE',skip,str(e),flush=True); return {'results':[]}
   time.sleep(2)
seen={}
for begin in range(0,10000,500):
 with ThreadPoolExecutor(max_workers=3) as pool:
  for data in pool.map(fetch,range(begin,begin+500,100)):
   for item in data.get('results',[]):
    f=item.get('openfda',{}); key=(' | '.join(f.get('brand_name',[])).lower(),' | '.join(f.get('generic_name',[])).lower())
    ftext=' '.join(item.get('dosage_forms_and_strengths',[])+item.get('spl_product_data_elements',[]))
    dosage=' '.join(item.get('dosage_forms_and_strengths',[])+item.get('active_ingredient',[]))
    forms=sum(bool(re.search(p,ftext,re.I)) for p in [r'capsul',r'tablet|caplet',r'oral solution',r'suspension'])
    eligible=len(f.get('substance_name',[]))<=1 and not re.search(r'\band\b|,|;',key[1],re.I) and forms==1 and re.search(r'capsul|tablet|caplet',ftext,re.I) and re.search(r'\d+(?:\.\d+)?\s*(?:mcg|mg|g)\b',dosage,re.I)
    if key[0] and key[1] and eligible: seen.setdefault(key,item)
 print('UNIQUE_BRAND_GENERIC',len(seen),'RECORDS_SCANNED',begin+500,flush=True)
 (out/'products_supported.json').write_text(json.dumps(list(seen.values())[:1000]))
 if len(seen)>=1000: break
print('COLLECTION_COMPLETE',min(len(seen),1000),flush=True)
